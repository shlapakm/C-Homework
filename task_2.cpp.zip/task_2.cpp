#include <iostream>
#include "erg.h"
#include "ev.h"
int main() {
	double energy;
	std::cout << "Please, enter a value of energy in Joule" << std::endl;
	std::cin >> energy;
	short unitsOfMeasurement;
	std::cout << "Please, choice an units of measurement: enter 1 if it is erg or enter 0 if it is ev" << std::endl;
	std::cin >> unitsOfMeasurement;
	switch (unitsOfMeasurement) {
	case 1:
		std::cout << Erg::getEnergy(energy);
		break;
	default:
		std::cout << Ev::getEnergy(energy);
		break;
	}
	return 0;
}
