
#include <iostream>
namespace Ev {
	static long double jouleToEv = 6.2 * 1000000000000000000;
	long double getEnergy(long double energy) {
		return jouleToEv*energy;
	}
}

