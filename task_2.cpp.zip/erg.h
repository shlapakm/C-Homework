
#include <iostream>
namespace Erg {
	static long double jouleToErg = 10000000;
	long double getEnergy(long double energy) {
		return jouleToErg*energy;
	}
}

